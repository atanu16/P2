using System.Windows;

namespace GlassApp;

public partial class App : Application
{
    public static bool IsDarkMode { get; private set; } = true;

    public static void ToggleTheme()
    {
        IsDarkMode = !IsDarkMode;
        var dict = new ResourceDictionary
        {
            Source = IsDarkMode
                ? new Uri("pack://application:,,,/Themes/DarkTheme.xaml")
                : new Uri("pack://application:,,,/Themes/LightTheme.xaml")
        };
        Current.Resources.MergedDictionaries.Clear();
        Current.Resources.MergedDictionaries.Add(dict);
    }
}
