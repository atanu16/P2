using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace GlassApp.Views;

public record OrderItem(
    string Id,
    string Customer,
    string Initials,
    string Date,
    string Amount,
    string Status,
    Brush StatusColor,
    Brush StatusBg
);

public partial class DashboardWindow : Window
{
    private readonly double[] _chartData = [
        42000, 58000, 51000, 67000, 73000, 88000,
        79000, 95000, 104000, 112000, 98000, 128000
    ];

    public DashboardWindow()
    {
        InitializeComponent();
        LoadOrders();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
        // Defer chart drawing until layout is complete
        Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Loaded, DrawChart);
    }

    private void DrawChart()
    {
        ChartCanvas.Children.Clear();

        double w = ChartCanvas.ActualWidth;
        double h = ChartCanvas.ActualHeight;
        if (w <= 0 || h <= 0) return;

        double maxVal = _chartData.Max();
        double minVal = _chartData.Min() * 0.85;
        double range  = maxVal - minVal;
        int    n      = _chartData.Length;
        double padL   = 8;
        double padR   = 8;
        double padT   = 10;
        double padB   = 10;
        double chartW = w - padL - padR;
        double chartH = h - padT - padB;

        // Grid lines
        var gridBrush = (Brush)FindResource("ChartGridBrush");
        for (int g = 0; g <= 4; g++)
        {
            double y = padT + chartH * g / 4.0;
            var line = new Line
            {
                X1 = padL, X2 = w - padR, Y1 = y, Y2 = y,
                Stroke = gridBrush, StrokeThickness = 1,
                StrokeDashArray = new DoubleCollection([4, 4])
            };
            ChartCanvas.Children.Add(line);
        }

        // Compute points
        var points = new PointCollection();
        for (int i = 0; i < n; i++)
        {
            double x = padL + i * chartW / (n - 1);
            double y = padT + chartH - ((_chartData[i] - minVal) / range) * chartH;
            points.Add(new Point(x, y));
        }

        // Area fill polygon
        var areaPoints = new PointCollection();
        areaPoints.Add(new Point(points[0].X, padT + chartH));
        foreach (var p in points) areaPoints.Add(p);
        areaPoints.Add(new Point(points[n - 1].X, padT + chartH));

        var area = new Polygon
        {
            Points  = areaPoints,
            Fill    = (Brush)FindResource("ChartFillBrush"),
            Stroke  = Brushes.Transparent,
            StrokeThickness = 0
        };
        ChartCanvas.Children.Add(area);

        // Line
        var polyline = new Polyline
        {
            Points          = points,
            Stroke          = (Brush)FindResource("ChartLineBrush"),
            StrokeThickness = 2.5,
            StrokeLineJoin  = PenLineJoin.Round,
            StrokeStartLineCap = PenLineCap.Round,
            StrokeEndLineCap   = PenLineCap.Round
        };
        ChartCanvas.Children.Add(polyline);

        // Dots on data points
        var dotBrush = (Brush)FindResource("ChartLineBrush");
        for (int i = 0; i < n; i++)
        {
            // outer ring
            var ring = new Ellipse
            {
                Width  = 10, Height = 10,
                Fill   = Brushes.Transparent,
                Stroke = dotBrush,
                StrokeThickness = 1.5
            };
            Canvas.SetLeft(ring, points[i].X - 5);
            Canvas.SetTop(ring,  points[i].Y - 5);
            ChartCanvas.Children.Add(ring);

            // inner dot
            var dot = new Ellipse
            {
                Width  = 5, Height = 5,
                Fill   = dotBrush
            };
            Canvas.SetLeft(dot, points[i].X - 2.5);
            Canvas.SetTop(dot,  points[i].Y - 2.5);
            ChartCanvas.Children.Add(dot);
        }

        // Tooltip glow on last point (highlight)
        var glow = new Ellipse
        {
            Width  = 18, Height = 18,
            Fill   = Brushes.Transparent,
            Stroke = dotBrush,
            StrokeThickness = 1,
            Opacity = 0.4
        };
        Canvas.SetLeft(glow, points[n - 1].X - 9);
        Canvas.SetTop(glow,  points[n - 1].Y - 9);
        ChartCanvas.Children.Add(glow);

        // Label on last point
        var lbl = new TextBlock
        {
            Text       = "$128K",
            FontSize   = 11,
            FontWeight = FontWeights.SemiBold,
            Foreground = dotBrush
        };
        Canvas.SetLeft(lbl, points[n - 1].X - 22);
        Canvas.SetTop(lbl,  points[n - 1].Y - 22);
        ChartCanvas.Children.Add(lbl);
    }

    private void LoadOrders()
    {
        var success = new SolidColorBrush(Color.FromArgb(0xFF, 0x00, 0xE5, 0xA0));
        var successBg = new SolidColorBrush(Color.FromArgb(0x20, 0x00, 0xE5, 0xA0));
        var warning = new SolidColorBrush(Color.FromArgb(0xFF, 0xFF, 0xAB, 0x40));
        var warningBg = new SolidColorBrush(Color.FromArgb(0x20, 0xFF, 0xAB, 0x40));
        var danger = new SolidColorBrush(Color.FromArgb(0xFF, 0xFF, 0x57, 0x57));
        var dangerBg = new SolidColorBrush(Color.FromArgb(0x20, 0xFF, 0x57, 0x57));
        var accent = new SolidColorBrush(Color.FromArgb(0xFF, 0x00, 0xC8, 0xFF));
        var accentBg = new SolidColorBrush(Color.FromArgb(0x20, 0x00, 0xC8, 0xFF));

        var orders = new List<OrderItem>
        {
            new("#4921", "Sarah Mitchell",  "SM", "Mar 28, 2025", "$349.00",  "Completed", success, successBg),
            new("#4920", "James Thornton",  "JT", "Mar 27, 2025", "$1,240.00","Processing", accent,  accentBg),
            new("#4919", "Elena Vasquez",   "EV", "Mar 27, 2025", "$89.99",   "Shipped",    success, successBg),
            new("#4918", "Michael Chen",    "MC", "Mar 26, 2025", "$3,200.00","Pending",    warning, warningBg),
            new("#4917", "Aisha Okonkwo",   "AO", "Mar 25, 2025", "$560.50",  "Completed",  success, successBg),
            new("#4916", "David Kowalski",  "DK", "Mar 24, 2025", "$74.00",   "Cancelled",  danger,  dangerBg),
        };

        OrdersTable.ItemsSource = orders;
    }

    private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        // Only drag from header area
        if (e.GetPosition(this).Y < 64)
            try { DragMove(); } catch { }
    }

    private void BtnClose_Click(object sender, RoutedEventArgs e)
        => Application.Current.Shutdown();

    private void BtnMinimize_Click(object sender, RoutedEventArgs e)
        => WindowState = WindowState.Minimized;

    private void BtnMaximize_Click(object sender, RoutedEventArgs e)
    {
        WindowState = WindowState == WindowState.Maximized
            ? WindowState.Normal
            : WindowState.Maximized;
    }

    private void BtnTheme_Click(object sender, RoutedEventArgs e)
    {
        App.ToggleTheme();
        // Redraw chart with new colors
        Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Render, DrawChart);
    }

    private void BtnLogout_Click(object sender, RoutedEventArgs e)
    {
        var login = new LoginWindow();
        login.Show();
        this.Close();
    }

    private void NavDashboard_Click(object sender, RoutedEventArgs e)
    {
        // Already on dashboard
    }

    protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo)
    {
        base.OnRenderSizeChanged(sizeInfo);
        Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Render, DrawChart);
    }
}
