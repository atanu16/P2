using System.Windows;
using System.Windows.Input;

namespace GlassApp.Views;

public partial class LoginWindow : Window
{
    // Temporary credentials
    private const string TempUsername = "Atanu";
    private const string TempPassword = "123";

    public LoginWindow()
    {
        InitializeComponent();
        TxtUsername.Text     = TempUsername;
        TxtPassword.Password = TempPassword;
    }

    private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        // Only drag from non-interactive areas so textboxes stay clickable
        var src = e.OriginalSource as FrameworkElement;
        if (src is System.Windows.Controls.TextBox     ||
            src is System.Windows.Controls.PasswordBox ||
            src is System.Windows.Controls.CheckBox    ||
            src is System.Windows.Controls.Button)
            return;

        try { DragMove(); } catch { }
    }

    private void BtnClose_Click(object sender, RoutedEventArgs e)
        => Application.Current.Shutdown();

    private void BtnMinimize_Click(object sender, RoutedEventArgs e)
        => WindowState = WindowState.Minimized;

    private void BtnTheme_Click(object sender, RoutedEventArgs e)
        => App.ToggleTheme();

    private void BtnLogin_Click(object sender, RoutedEventArgs e)
    {
        string username = TxtUsername.Text.Trim();
        string password = TxtPassword.Password;

        if (username == TempUsername && password == TempPassword)
        {
            var dashboard = new DashboardWindow();
            dashboard.Show();
            this.Close();
        }
        else
        {
            ErrorBanner.Visibility = Visibility.Visible;
            ErrorText.Text         = $"Invalid credentials. Hint: {TempUsername} / {TempPassword}  (temporary)";
        }
    }
}
